namespace devoirMaison.Models
{
    public enum EDamageType
    {
        Physical,
        Holy,
        Poisonous
    }
}